package org.junit.internal;

import java.io.PrintStream;

public interface JUnitSystem {
    PrintStream out();
}
