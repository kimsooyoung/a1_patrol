#ifndef TPRK77_LCM_PACK_H
#define TPRK77_LCM_PACK_H

#ifdef __cplusplus
extern "C" {
#endif
#include "lauxlib.h"
#include "lua.h"
#ifdef __cplusplus
}
#endif

void ll_pack_register(lua_State *);

#endif
