#!/bin/sh

rm -rf exlcm
